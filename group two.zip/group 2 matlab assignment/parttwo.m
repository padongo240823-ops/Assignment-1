%%designing to struct
members=struct('name',{},'age',{},'religion',{},'village',{},'facialrepresentation',{},'course',{},'interests',{},'tribes',{});
%members(1)
members(1).name=('chelimo sandra');
members(1).age=('30');
members(1).religion=('anglican');
members(1).village=('taragon');
members(1).facialrepresentation=imread('ngc6543a.jpg');
members(1).course=('war');
members(1).interests=('food');
members(1).tribes=('sabiny');
%members(2)
members(2).name=('muhangi mouris');
members(2).age=('25');
members(2).religion=('pentecostal');
members(2).village=('kampala');
members(2).facialrepresentation=imread('ngc6543a.jpg');
members(2).course=('meb');
members(2).interests=('prayer');
members(2).tribes=('munyankole');
%members(3)
members(3).name = 'econi ronald';
members(3).age = '24';
members(3).religion = 'anglican';
members(3).village = 'drandrua';
members(3).course = 'ami';
members(3).interests = 'dancing';
members(3).tribes = 'lugbara';
%members(4)
members(4).name = 'adongo poffia';
members(4).age = '27';
members(4).religion = 'pentecostal';
members(4).village = 'soroti';
members(4).course = 'ami';
members(4).interests = 'eating';
members(4).tribes = 'acholi';
%members(5)
members(5).name = 'obur charles';
members(5).age = '21';
members(5).religion = 'catholic';
members(5).village = 'agago';
members(5).course = 'ape';
members(5).interests = 'music';
members(5).tribes = 'acholi';
%members(6)
members(6).name = 'nakazibwe ethel';
members(6).age = '35';
members(6).religion = 'pentecostal';
members(6).village = 'kawanda';
members(6).course = 'ami';
members(6).interests = 'chess';
members(6).tribes = 'lugbara';
%member(7)
members(7).name = 'ogutu daniel wafula';
members(7).age = '21';
members(7).religion = 'anglican';
members(7).village = 'makina';
members(7).course = 'war';
members(7).interests = 'catering';
members(7).tribes = 'samia';
%member(8)
members(8).name = 'owor hamidu';
members(8).age = '22';
members(8).religion = 'islam';
members(8).village = 'ntawo';
members(8).course = 'pti';
members(8).interests = 'writing';
members(8).tribes = 'mugisu';
%member(9)
members(9).name = 'onanyang francis';
members(9).age = '26';
members(9).religion = 'anglican';
members(9).village = 'kumi';
members(9).course = 'war';
members(9).interests = 'playing';
members(9).tribes = 'etesot';
%member(10)
members(10).name = 'odongo joseph';
members(10).age = '23';
members(10).religion = 'catholic';
members(10).village = 'lira';
members(10).course = 'ami';
members(10).interests = 'music';
members(10).tribes = 'langi';
%% Extract data into arrays/tables
ages = str2double({members.age});
names = {members.name};
religions = {members.religion};
villages = {members.village};
courses = {members.course};
interests = {members.interests};
tribes = {members.tribes};
%% ---Descriptive Statistics---
fprintf('===== Descriptive Statistics =====');
fprintf('Number of Members: %d\n', numel(members));
fprintf('Mean Age: %.2f\n', mean(ages));
fprintf('Median Age: %.2f\n', median(ages));
fprintf('Maximum Age: %d\n', max(ages));
fprintf('Minimun Age: %d\n', min(ages));
fprintf('Age Range: %d\n', max(ages)-min(ages));
fprintf('Standard Deviation of Ages: %2f\n\n', std(ages));
%% Frequency Summeries
religionCategories = unique(religions);
religionCounts = cellfun(@(x) sum(strcmp(religions,x)), religionCategories);

courseCategories = unique(courses);
courseCounts = cellfun(@(x) sum(strcmp(courses,x)), courseCategories);

tribeCategories = unique(tribes);
tribeCounts = cellfun(@(x) sum(strcmp(tribes,x)), tribeCategories);

villageCategories = unique(villages);
villageCounts = cellfun(@(x) sum(strcmp(villages,x)), villageCategories);

interestCategories = unique(interests);
interestCounts = cellfun(@(x) sum(strcmp(interests,x)), interestCategories);
%% visualization
% a. Histogram of Ages
figure;
histogram(ages, 'FaceColor',[0.2 0.6 0.8], 'EdgeColor','k');
xlabel('Age');
ylabel('Frequency');
title('Age Distribution of Members')

% b. Pie chart of Religions
figure;
pie(religionCounts, religionCategories);
title('Religion Distribution');

% c. Bar Charts Of Courses
figure;
bar(categorical(courseCategories), courseCounts, 'FaceColor',[0.3 0.8 0.4]);
xlabel('Course');
ylabel('Number of Members');
title('Course Distribution');

% d. Bar Chart of Tribes
figure;
bar(categorical(tribeCategories), tribeCounts, 'FaceColor',[0.9 0.4 0.5]);
xlabel('Tribe');
ylabel('Number of Members');
title('Tribe Distribution');

% e. Bar Chart of Villages
figure;
bar(categorical(villageCategories), villageCounts,'FaceColor',[0.5 0.5 0.9]);
xlabel('village');
ylabel('Number of Members');
title('Village Distribution')

% f. Cross-analysis: Age by Religion
figure;
boxplot(ages, religions);
xlabel('Religion');
ylabel('Age')
title('Age Distribution across Religions');

% g. Cross-analysis: Age by Course
figure;
boxplot(ages, courses);
xlabel('Course');
ylabel('Age');
title('Age Distribution across Courses');
save second part



